# Diwaxan online starter (Android + iOS)

This is an **integration starter**, not a deployed service or tested build. The existing `lib/main.dart` remains the offline demo. The online version is `lib/online_main.dart`.

1. Install Flutter, Android SDK, and (for iOS) macOS/Xcode. Run `flutter create --platforms=android,ios --project-name diwaxan_app .` in this directory.
2. Run `flutter pub add firebase_core firebase_auth cloud_firestore livekit_client http`.
3. Create a Firebase project, register Android and iOS apps, enable **Anonymous Authentication** and **Cloud Firestore**. Configure FlutterFire (`dart pub global activate flutterfire_cli`, then `flutterfire configure`); add platform Firebase configuration and adapt Firebase initialization to use generated `firebase_options.dart` if required by your platform.
4. Deploy `firestore.rules` using Firebase CLI. Review and harden rules before public use.
5. Create a LiveKit Cloud project (or host LiveKit). Keep the API key/secret **server-side only**.
6. Deploy the Node token server from `server/` to HTTPS hosting. Run `npm install` and configure `GOOGLE_APPLICATION_CREDENTIALS`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, and `PORT`. Do not commit credentials. Protect the endpoint with rate limiting and abuse monitoring.
7. Run `flutter run -t lib/online_main.dart --dart-define=TOKEN_ENDPOINT=https://YOUR_HOST/token --dart-define=LIVEKIT_URL=wss://YOUR_LIVEKIT_HOST`.
8. Add microphone permission: Android `RECORD_AUDIO` in `android/app/src/main/AndroidManifest.xml`; iOS `NSMicrophoneUsageDescription` in `ios/Runner/Info.plist`. Check the LiveKit SDK's current Android/iOS setup guidance.
9. Test with **two physical devices** and separate accounts; ensure seat updates, messages and mic permission work. Then build APK/iOS signed builds.

## Security / product caveats
- Voice access is currently **independent of seat occupancy**. A production token server must check seat authorization and roles, and the backend should enforce one seat per user with server-managed transactions; current Firestore seat rules do not guarantee uniqueness across seats.
- The online starter uses anonymous auth; production needs account recovery, moderation, abuse reporting, room access policy, message retention, privacy disclosures, and token/room lifecycle management.
- Gifts, coins, VIP and lucky box remain **local demo UI** in `main.dart`; never treat client-side coins as real balances or accept payments until a secure backend and platform billing are implemented.
- Do not put LiveKit API secrets or Firebase admin credentials in the Flutter app.
- This environment has no Flutter SDK and cannot compile or device-test this project.
