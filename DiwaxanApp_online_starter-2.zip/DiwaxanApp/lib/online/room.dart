import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:livekit_client/livekit_client.dart';

class OnlineRoom extends StatefulWidget {
  const OnlineRoom({super.key});
  @override State<OnlineRoom> createState() => _OnlineRoomState();
}

class _OnlineRoomState extends State<OnlineRoom> {
  static const roomId = 'qalai-hawler';
  final input = TextEditingController();
  final room = Room();
  bool connected = false, muted = true, busy = false;
  String? error;
  String get uid => FirebaseAuth.instance.currentUser!.uid;
  DocumentReference<Map<String, dynamic>> get roomDoc => FirebaseFirestore.instance.collection('rooms').doc(roomId);
  CollectionReference<Map<String, dynamic>> get messages => roomDoc.collection('messages');
  CollectionReference<Map<String, dynamic>> get seats => roomDoc.collection('seats');

  Future<void> joinVoice() async {
    if (busy || connected) return;
    setState(() { busy = true; error = null; });
    try {
      const endpoint = String.fromEnvironment('TOKEN_ENDPOINT');
      const livekitUrl = String.fromEnvironment('LIVEKIT_URL');
      if (endpoint.isEmpty || livekitUrl.isEmpty) throw Exception('TOKEN_ENDPOINT / LIVEKIT_URL نەدراوە');
      final idToken = await FirebaseAuth.instance.currentUser!.getIdToken();
      final res = await http.post(Uri.parse(endpoint), headers: {'Authorization':'Bearer $idToken', 'Content-Type':'application/json'}, body: jsonEncode({'room': roomId})).timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) throw Exception('Token server: ${res.statusCode}');
      final token = jsonDecode(res.body)['token'] as String;
      await room.connect(livekitUrl, token);
      await room.localParticipant?.setMicrophoneEnabled(false);
      if (mounted) setState(() { connected = true; muted = true; });
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> toggleMic() async {
    if (!connected) return;
    try {
      await room.localParticipant?.setMicrophoneEnabled(muted);
      if (mounted) setState(() => muted = !muted);
    } catch (e) { if (mounted) setState(() => error = '$e'); }
  }

  Future<void> takeSeat(int index) async {
    final ref = seats.doc('$index');
    try {
      await FirebaseFirestore.instance.runTransaction((tx) async {
        final all = <DocumentSnapshot<Map<String, dynamic>>>[];
        for (var i = 0; i < 8; i++) { all.add(await tx.get(seats.doc('$i'))); }
        final target = all[index].data()?['uid'];
        if (target != null && target != uid) throw Exception('ئەم کورسییە گیراوە');
        for (var i = 0; i < 8; i++) {
          if (i != index && all[i].data()?['uid'] == uid) tx.delete(seats.doc('$i'));
        }
        if (target == uid) { tx.delete(ref); }
        else { tx.set(ref, {'uid': uid, 'name': 'میوان ${uid.substring(0, 5)}', 'joinedAt': FieldValue.serverTimestamp()}); }
      });
    } catch (e) { if (mounted) setState(() => error = '$e'); }
  }

  Future<void> sendMessage() async {
    final text = input.text.trim();
    if (text.isEmpty || text.length > 500) return;
    input.clear();
    try {
      await messages.add({'uid': uid, 'name': 'میوان ${uid.substring(0, 5)}', 'text': text, 'createdAt': FieldValue.serverTimestamp()});
    } catch (e) { if (mounted) setState(() => error = '$e'); }
  }

  @override void dispose() { room.disconnect(); room.dispose(); input.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF140B26),
      appBar: AppBar(backgroundColor: const Color(0xFF241438), title: const Text('دیوەخان • قەڵای هەولێر')),
      body: SafeArea(child: Column(children: [
        const Padding(padding: EdgeInsets.all(12), child: Text('ژووری ئۆنلاین • ٨ کورسی', style: TextStyle(color: Colors.amber, fontSize: 18))),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: seats.snapshots(),
          builder: (context, snap) {
            final occupants = {for (final doc in snap.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) int.tryParse(doc.id) ?? -1: doc.data()};
            return GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: 8,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, childAspectRatio: 1.0),
              itemBuilder: (context, i) {
                final user = occupants[i];
                return InkWell(onTap: () => takeSeat(i), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  CircleAvatar(backgroundColor: user?['uid'] == uid ? Colors.amber : Colors.deepPurple, child: Icon(user == null ? Icons.chair : Icons.person, color: Colors.white)),
                  const SizedBox(height: 5), Text(user?['name'] ?? 'کورسی ${i + 1}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
                ]));
              });
          }),
        if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: messages.orderBy('createdAt', descending: true).limit(50).snapshots(),
          builder: (context, snap) => ListView(children: [for (final doc in snap.data?.docs ?? <QueryDocumentSnapshot<Map<String, dynamic>>>[]) ListTile(dense: true, title: Text(doc.data()['name'] ?? 'میوان'), subtitle: Text(doc.data()['text'] ?? ''))]),
        )),
        Padding(padding: const EdgeInsets.all(8), child: Row(children: [
          Expanded(child: TextField(controller: input, maxLength: 500, decoration: const InputDecoration(hintText: 'پەیام بنووسە...', counterText: ''))),
          IconButton(onPressed: sendMessage, icon: const Icon(Icons.send)),
          ElevatedButton(onPressed: busy ? null : (connected ? toggleMic : joinVoice), child: Text(!connected ? 'بەشداری دەنگ' : muted ? 'مایک بکەرەوە' : 'مایک دابخە')),
        ])),
      ])),
    );
  }
}
