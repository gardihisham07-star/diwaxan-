// Run with: flutter run -t lib/online_main.dart --dart-define=TOKEN_ENDPOINT=https://YOUR_SERVER/token --dart-define=LIVEKIT_URL=wss://YOUR_LIVEKIT_HOST
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:livekit_client/livekit_client.dart';
import 'online/room.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Requires platform Firebase configuration.
  await FirebaseAuth.instance.signInAnonymously();
  runApp(const MaterialApp(debugShowCheckedModeBanner: false, home: Directionality(textDirection: TextDirection.rtl, child: OnlineRoom())));
}
