import 'package:flutter/material.dart';

void main() => runApp(const DiwaxanApp());

class DiwaxanApp extends StatelessWidget {
  const DiwaxanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'دیوەخان',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF100A20),
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.amber, brightness: Brightness.dark),
    ),
    home: const VoiceRoomScreen(),
  );
}

class VoiceRoomScreen extends StatefulWidget {
  final String roomTitle;
  const VoiceRoomScreen({super.key, this.roomTitle = 'قەڵای هەولێر'});
  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> with SingleTickerProviderStateMixin {
  static const gold = Color(0xFFFFC857);
  final messageController = TextEditingController();
  late final AnimationController pulse;
  final List<Map<String, dynamic>> seats = [
    {'name':'خاوەن ژوور','avatar':'https://i.pravatar.cc/150?img=11','host':true,'speaking':true},
    {'name':'شیلان','avatar':'https://i.pravatar.cc/150?img=5','host':false,'speaking':false},
    {'name':'ئاوات','avatar':'https://i.pravatar.cc/150?img=12','host':false,'speaking':true},
    ...List.generate(5, (_) => <String,dynamic>{'name':'بەتاڵ','avatar':'','host':false,'speaking':false}),
  ];
  final List<Map<String, String>> messages = [
    {'user':'ئاوات','text':'بەخێربێن بۆ دیوەخان ❤️'},
    {'user':'سیستەم','text':'شیلان هاتە ناو ژوورەکە'},
  ];
  final List<String> history = [];
  final gifts = const [
    {'name':'گوڵ 🌹','price':100,'emoji':'🌹'},
    {'name':'چای 🫖','price':200,'emoji':'🫖'},
    {'name':'قاوە ☕','price':300,'emoji':'☕'},
    {'name':'دڵ 💖','price':500,'emoji':'💖'},
    {'name':'قەڵای هەولێر 🏰','price':5000,'emoji':'🏰'},
    {'name':'سەیارەی زێڕین 🚘','price':20000,'emoji':'🚘'},
  ];
  bool muted = false;
  bool handRaised = false;
  int? mySeat;
  int coins = 50000;
  String? giftOverlay;

  @override
  void initState() {
    super.initState();
    pulse = AnimationController(vsync:this, duration:const Duration(milliseconds:850))..repeat(reverse:true);
  }
  @override
  void dispose() {
    pulse.dispose();
    messageController.dispose();
    super.dispose();
  }
  void notice(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text),duration:const Duration(seconds:2)));
  void systemMessage(String text) => setState(() => messages.add({'user':'سیستەم','text':text}));
  void sendMessage() {
    final text = messageController.text.trim();
    if (text.isEmpty) return;
    setState(() { messages.add({'user':'من','text':text}); messageController.clear(); });
  }
  void toggleSeat(int index) {
    if (index == 0) { notice('ئەم کورسییە بۆ خاوەن ژوورە'); return; }
    if (index < 3) { notice('ئەم کورسییە پڕە'); return; }
    setState(() {
      if (mySeat == index) {
        seats[index] = {'name':'بەتاڵ','avatar':'','host':false,'speaking':false};
        mySeat = null;
        messages.add({'user':'سیستەم','text':'من لە کورسی هەستامەوە'});
      } else {
        if (mySeat != null) seats[mySeat!] = {'name':'بەتاڵ','avatar':'','host':false,'speaking':false};
        seats[index] = {'name':'من','avatar':'','host':false,'speaking':!muted,'occupied':true};
        mySeat = index;
        handRaised = false;
        messages.add({'user':'سیستەم','text':'من لە کورسی ${index + 1} دانیشتم'});
      }
    });
  }
  void sendGift(Map<String, dynamic> gift) {
    final int price = gift['price'] as int;
    if (coins < price) { notice('کۆینی پێویستت نییە'); return; }
    setState(() {
      coins -= price;
      giftOverlay = gift['emoji'] as String;
      history.insert(0, '${gift['name']} — $price کۆین');
      messages.add({'user':'سیستەم','text':'من دیاریی ${gift['name']} نارد'});
    });
    Navigator.of(context).pop();
  }
  void openGifts() => showModalBottomSheet<void>(
    context:context, backgroundColor:const Color(0xFF25153D), isScrollControlled:true,
    builder:(sheetContext) => SafeArea(child:Padding(
      padding:const EdgeInsets.all(16),
      child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text('🎁 دیارییەکان | باڵانس: $coins کۆین',style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:gifts.length,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,childAspectRatio:0.9,crossAxisSpacing:8,mainAxisSpacing:8),
          itemBuilder:(context,i) { final gift=gifts[i]; return InkWell(
            onTap:()=>sendGift(gift),borderRadius:BorderRadius.circular(12),
            child:Container(decoration:BoxDecoration(color:Colors.white10,borderRadius:BorderRadius.circular(12)),
              child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                Text(gift['emoji'] as String,style:const TextStyle(fontSize:34)),
                Text(gift['name'] as String,textAlign:TextAlign.center,style:const TextStyle(fontSize:11)),
                Text('${gift['price']} 🪙',style:const TextStyle(color:gold,fontSize:12)),
              ])),); }),
        const SizedBox(height:8),
        const Text('ئەم دیارییانە تەنها نموونەی تاقیکردنەوەن.',style:TextStyle(color:Colors.white54,fontSize:11)),
      ]),
    )),
  );
  void showProfile() => showModalBottomSheet<void>(context:context,backgroundColor:const Color(0xFF25153D),builder:(context)=>SafeArea(child:Padding(
    padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,children:[
      const CircleAvatar(radius:32,child:Icon(Icons.person,size:35)),
      const SizedBox(height:8),const Text('من | VIP 1',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      Text('🪙 $coins کۆین',style:const TextStyle(color:gold)),
      const Divider(),const Text('مێژووی دیارییەکان'),
      SizedBox(height:140,child:history.isEmpty?const Center(child:Text('هێشتا دیاریت نەناردووە')):ListView(children:history.map((h)=>ListTile(dense:true,title:Text(h))).toList())),
    ]),
  )));
  void openLuckyBox() => showDialog<void>(context:context,builder:(context)=>AlertDialog(
    title:const Text('🎁 سندوقی بەخت'),
    content:const Text('ئەم بەشە لە وەشانی تاقیکردنەوەدا تەنها پیشاندانی ڕووکارە؛ خەڵات بە شێوەی ڕاستەقینە دابەش ناکات.'),
    actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('باشە'))],
  ));

  @override
  Widget build(BuildContext context) => Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    body:SafeArea(child:Container(
      decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Color(0xFF291448),Color(0xFF100A20)])),
      child:Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(10,8,10,4),child:Row(children:[
          IconButton(onPressed:()=>Navigator.maybePop(context),icon:const Icon(Icons.arrow_back)),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.roomTitle,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:19)),
            const Text('٣ بەشداربوو • ژووری تاقیکردنەوە',style:TextStyle(color:Colors.white60,fontSize:11)),
          ])),
          TextButton.icon(onPressed:showProfile,icon:const Icon(Icons.workspace_premium,color:gold),label:const Text('VIP',style:TextStyle(color:gold))),
        ])),
        InkWell(onTap:openLuckyBox,child:Container(margin:const EdgeInsets.all(12),padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:const Color(0xFF3A2456),borderRadius:BorderRadius.circular(14),border:Border.all(color:gold.withOpacity(0.4))),
          child:const Row(children:[Icon(Icons.card_giftcard,color:gold),SizedBox(width:10),Expanded(child:Text('سندوقی بەختی دیوەخان')),Text('بەشداری بکە',style:TextStyle(color:gold,fontSize:12))]))),
        Padding(padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:GridView.builder(
          shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:seats.length,
          gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,mainAxisSpacing:10,crossAxisSpacing:8,childAspectRatio:0.86),
          itemBuilder:(context,i){ final seat=seats[i]; final avatar=seat['avatar'] as String;
            final occupied=avatar.isNotEmpty || seat['occupied']==true;
            final speaking=seat['speaking']==true;
            return InkWell(onTap:()=>toggleSeat(i),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
              AnimatedBuilder(animation:pulse,builder:(context,child)=>Container(
                padding:EdgeInsets.all(speaking?2+3*pulse.value:3),
                decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:speaking?gold:Colors.white24,width:speaking?2:1)),
                child:child),child:CircleAvatar(radius:24,backgroundColor:const Color(0xFF42305B),
                backgroundImage:avatar.isNotEmpty?NetworkImage(avatar):null,
                child:avatar.isEmpty?Icon(occupied?Icons.person:Icons.add,color:Colors.white70):null)),
              const SizedBox(height:5),
              Text(seat['name'] as String,maxLines:1,overflow:TextOverflow.ellipsis,style:TextStyle(fontSize:11,color:occupied?Colors.white:Colors.white54)),
              if (seat['host']==true) const Text('👑 HOST',style:TextStyle(fontSize:9,color:gold)),
            ]));
          })),
        if(giftOverlay!=null) Padding(padding:const EdgeInsets.all(5),child:Column(children:[
          Text(giftOverlay!,style:const TextStyle(fontSize:52)),
          TextButton(onPressed:()=>setState(()=>giftOverlay=null),child:const Text('داخستن ✕')),
        ])),
        const Spacer(),
        SizedBox(height:145,child:ListView.builder(reverse:true,padding:const EdgeInsets.symmetric(horizontal:12),itemCount:messages.length,
          itemBuilder:(context,i){final m=messages[messages.length-1-i];final sys=m['user']=='سیستەم';return Padding(
            padding:const EdgeInsets.only(bottom:5),child:Align(alignment:Alignment.centerRight,child:Container(
              padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),
              decoration:BoxDecoration(color:Colors.black38,borderRadius:BorderRadius.circular(9)),
              child:Text.rich(TextSpan(children:[TextSpan(text:'${m['user']}: ',style:TextStyle(color:sys?gold:Colors.cyanAccent,fontWeight:FontWeight.bold)),TextSpan(text:m['text'])]),style:const TextStyle(fontSize:12)),
            ))); })),
        Container(padding:const EdgeInsets.fromLTRB(8,10,8,10),decoration:const BoxDecoration(color:Color(0xFF211331),borderRadius:BorderRadius.vertical(top:Radius.circular(18))),
          child:Row(children:[
            Expanded(child:TextField(controller:messageController,onSubmitted:(_)=>sendMessage(),textInputAction:TextInputAction.send,
              decoration:InputDecoration(hintText:'پەیامێک بنووسە...',isDense:true,filled:true,fillColor:Colors.white10,
                border:OutlineInputBorder(borderRadius:BorderRadius.circular(28),borderSide:BorderSide.none),
                suffixIcon:IconButton(onPressed:sendMessage,icon:const Icon(Icons.send,color:gold))))),
            IconButton(tooltip:'مایکرۆفۆن',onPressed:(){setState(() {muted=!muted;if(mySeat!=null)seats[mySeat!]['speaking']=!muted;});notice(muted?'مایک بێدەنگ کرا':'مایک چالاک کرا (نموونە)');},
              icon:Icon(muted?Icons.mic_off:Icons.mic,color:muted?Colors.redAccent:Colors.white)),
            IconButton(tooltip:'داواکردنی مایک',onPressed:(){setState(()=>handRaised=!handRaised);systemMessage(handRaised?'من داوای مایکم کرد':'من داوای مایکم هەڵوەشاندەوە');},
              icon:Icon(Icons.pan_tool,color:handRaised?gold:Colors.white70)),
            IconButton(tooltip:'دیاری',onPressed:openGifts,icon:const Icon(Icons.card_giftcard,color:gold)),
          ])),
      ]),
    )),
  ));
}
