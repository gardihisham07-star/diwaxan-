# Diwaxan | دیوەخان

Flutter demo source for **Android and iOS**. Includes 8 seats, local chat, demo gifts and coin balance, VIP/profile, microphone UI, animated speaking rings, and a lucky-box placeholder.

## Build from a computer with Flutter installed

```bash
flutter create --platforms=android,ios --project-name diwaxan_app .
flutter pub get
flutter run
```

Android APK: `flutter build apk --release` (output: `build/app/outputs/flutter-apk/app-release.apk`).
iOS: build on **macOS with Xcode**, e.g. `flutter build ios` and use Xcode signing. App Store distribution requires appropriate developer enrollment.

## Important limitations

This is a local interactive **prototype**, not a live voice chat service. Mic toggle is UI state only; no audio recording or transmission. Chats, gifts, seats and coins are local demo data and reset when the app restarts. No authentication, network room synchronization, payment, server or actual lucky-box payouts. Sample profile photos require Internet. Do not accept real money for coins with this prototype.

## Notes

`flutter create` generates the native Android/iOS folders, which are not included in this archive because Flutter SDK is unavailable in this environment. Do not overwrite `lib/main.dart` or `pubspec.yaml` when generating platform folders.
