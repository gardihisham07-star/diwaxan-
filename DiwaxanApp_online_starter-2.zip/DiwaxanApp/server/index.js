import express from 'express';
import admin from 'firebase-admin';
import { AccessToken } from 'livekit-server-sdk';

admin.initializeApp(); // Set GOOGLE_APPLICATION_CREDENTIALS on the server.
const app = express();
app.use(express.json({limit: '8kb'}));
app.post('/token', async (req, res) => {
  try {
    const bearer = req.headers.authorization || '';
    if (!bearer.startsWith('Bearer ')) return res.status(401).json({error:'Unauthorized'});
    const decoded = await admin.auth().verifyIdToken(bearer.slice(7));
    const room = req.body?.room;
    if (room !== 'qalai-hawler') return res.status(400).json({error:'Invalid room'});
    const {LIVEKIT_API_KEY: key, LIVEKIT_API_SECRET: secret} = process.env;
    if (!key || !secret) throw new Error('Missing LiveKit server credentials');
    const token = new AccessToken(key, secret, {identity: decoded.uid, ttl: '1h'});
    token.addGrant({roomJoin:true, room, canPublish:true, canSubscribe:true});
    return res.json({token: await token.toJwt()});
  } catch (e) { console.error(e); return res.status(401).json({error:'Authentication or token failure'}); }
});
app.listen(Number(process.env.PORT || 8080), '0.0.0.0');
